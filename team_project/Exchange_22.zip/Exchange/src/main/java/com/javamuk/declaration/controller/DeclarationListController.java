package com.javamuk.declaration.controller;

public class DeclarationListController {

}
