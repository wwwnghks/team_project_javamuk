package com.javamuk.declaration.service;

public class DeclarationListService {

}
