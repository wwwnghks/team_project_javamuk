package com.javamuk.declaration.persistence;

public class DeclarationListDAO {

}
