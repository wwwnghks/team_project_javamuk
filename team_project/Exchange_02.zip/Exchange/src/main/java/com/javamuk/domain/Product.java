package com.javamuk.domain;

public class Product {

}
